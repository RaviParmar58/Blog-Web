import { useContext, useState } from "react";
import { Link, Navigate } from "react-router-dom"
import toast, { Toaster } from "react-hot-toast";
import "./login-signup.css";
import Swal from "sweetalert2";
import { UserContext } from "../Context/UserContext";

function SignUp() {
  let [fullName, setFullName] = useState("");
  let [userName, setUserName] = useState("");
  let [email, setEmail] = useState("");
  let [password, setPassword] = useState("");
  let [requireError, setRequireError] = useState(false);
  let [userPhoto, setUserPhoto] = useState(['https://cdn-icons-png.flaticon.com/512/149/149071.png', '']);
  const [redirect, setRedirect] = useState(false);
  const {setUserInfo} = useContext(UserContext)

  async function signupUser(event) {
    event.preventDefault();

    if (!fullName || !userName || !email || !password) {
      setRequireError(true);
    }
    const userData = new FormData()
      userData.set('fullName', fullName.trim())
      userData.set('userName', userName.trim())
      userData.set('email', email.trim())
      userData.set('password', password.trim())
      userData.set('userImage', userPhoto[1][0])

    // const userData = {
    //   fullName: fullName.trim(),
    //   userName: userName.trim(),
    //   email: email.trim(),
    //   password: password.trim(),
    // };

    if (fullName && userName && email && password) {
      fetch("http://localhost:3008/signup", {
        method: "POST",
        body: userData,
        credentials: 'include'
      }).then(response => response.json().then(resData => {
        if(response.status === 200){
          setUserInfo(resData)
          Swal.fire({
            icon: "success",
            title: "Registration Successfull",
          });
          setFullName("");
          setUserName("");
          setEmail("");
          setPassword("");
          setUserPhoto(["", ""]);
          setRedirect(true)
        }
        else{
          toast.error(resData.message);
        }
      }))
    }
  }

  if (redirect) {
    return <Navigate to={`/`} />;
  }

  return (
    <>
      <div>
        <Toaster position="top-center" reverseOrder={false} />
      </div>

      <form className="signup-form" onSubmit={signupUser}>
        <div className="user-image" >
          <label for="userImage">
            <img src={userPhoto[0]} alt="user-image"/>
          </label>
          <input id="userImage" type="file" onChange={(event) => setUserPhoto([URL.createObjectURL(event.target.files[0]), event.target.files])} />
        </div>
        <div className="inputfield">
          <label>Full Name*</label>
          {requireError && !fullName && (
            <label className="text-danger">Full Name is require</label>
          )}
          <input
            type="text"
            value={fullName}
            onChange={(event) => setFullName(event.target.value)}
          />
        </div>
        <div className="inputfield">
          <label>Email *</label>
          {requireError && !email && (
            <label className="text-danger">Email is require</label>
          )}
          <input
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />
        </div>
        <div className="inputfield">
          <label>Create Username *</label>
          {requireError && !userName && (
            <label className="text-danger">Username is require</label>
          )}
          <input
            type="text"
            value={userName}
            onChange={(event) => setUserName(event.target.value)}
          />
        </div>
        <div className="inputfield">
          <label>Create Password *</label>
          {requireError && !password && (
            <label className="text-danger">Password is require</label>
          )}
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />
        </div>
        {/* <input type="file" onChange={(event) => setUserPhoto(URL.createObjectURL(event.target.files[0]))} /> */}
        {/* <img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSOELstfSIlPxq4esE_8FN54wM2T0BxwUydHsq_4pC3pKAiAPuBUNtIJehZYdzW8Xrf6A&usqp=CAU' alt="" /> */}
        {/* <img src={userPhoto} alt="" /> */}
        <p>Already have an account <Link to={'/login'}>Login</Link></p>
        <button>Signup</button>
      </form>
    </>
  );
}

export default SignUp;
