export function PageNotFound(){
    return(
        <>
            <img style={{height: '600px'}} src="https://img.freepik.com/free-vector/error-404-concept-landing-page_52683-12757.jpg?w=996&t=st=1698403506~exp=1698404106~hmac=7b23b9cdd0f56e267d30ac24f9d7f0f36418a4423e3e011dc4641f4e5662c015" alt="" />
        </>
    )
}