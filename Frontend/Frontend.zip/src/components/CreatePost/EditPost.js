import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"

export default function EditPost() {

    const [postData, setPostData] = useState('');
    const [title, setTitle] = useState('');
    const [summary, setSummary] = useState('');
    const [thumnail, setThumnail] = useState('');

    const param = useParams();

    useEffect(() => {
        const postData = fetch('http://localhost:3008/post/'+param.id)
        setPostData(postData)
    }, []);

    return(
        <>
            {postData && (
               <>
                    <input type="text" placeholder="Title" value={title}
                            onChange={event => setTitle(event.target.value)} />
                    <input type="text" placeholder="Summary" value={summary} 
                            onChange={setSummary} />
                    <input type="file" onChange={(e) => setThumnail(URL.createObjectURL(e.target.files[0]))}/>
                    <img src={thumnail} alt="" />
               </>
            )}
        </>
    )
}