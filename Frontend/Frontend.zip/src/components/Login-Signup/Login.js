import { useContext, useState } from "react";
import toast, { Toaster } from "react-hot-toast";
import { Link, Navigate } from "react-router-dom";
import { UserContext } from "../Context/UserContext";

function Login() {
  const [userName, setUsername] = useState("");
  const [password, setPassword] = useState("");
  let [requireError, setRequireError] = useState(false);
  const [redirect, setRedirect] = useState(false);

  const {setUserInfo} = useContext(UserContext)

  async function loginFun(event) {
    event.preventDefault();

    if (!userName || !password) {
      setRequireError(true);
    }

    if (userName && password) {
      const response = await fetch("http://localhost:3008/login", {
        method: "POST",
        body: JSON.stringify({ userName, password }),
        headers: { "Content-Type": "application/json" },
        credentials: "include",
      });
      if(response.ok){
        response.json().then(userData => {
          setUserInfo(userData)
          setRedirect(true)
        })
        toast.success('Login Success');
      }
      else{
        response.json().then(response => {
          toast.error(response);
        })
      }
    }
  }

  if(redirect){
    return <Navigate to={'/'}/>
  }

  return (
    <>
      <div>
        <Toaster position="top-center" reverseOrder={false} />
      </div>

      <form onSubmit={loginFun}>
        <div className="inputfield">
          <label>Username*</label>
          {requireError && !userName && (
            <label className="text-danger">Username require</label>
          )}
          <input
            type="text"
            value={userName}
            onChange={(event) => setUsername(event.target.value)}
          />
        </div>
        <div className="inputfield">
          <label>Password*</label>
          {requireError && !password && (
            <label className="text-danger">Password require</label>
          )}
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />
        </div>
        <p>Don't have an account <Link to={'/signup'}>Signup</Link></p>
        <button>Login</button>
      </form>
    </>
  );
}

export default Login;
